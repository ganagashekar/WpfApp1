﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Create150Charts();
        }

        private void Create150Charts()
        {
            int chartCount = 150;

            for (int i = 0; i < chartCount; i++)
            {
                var chart = new AdvancedRealtimeChart
                {
                    Width = 200,
                    Height = 50,
                    Margin = new Thickness(6),

                    Stroke = Brushes.Lime,
                    Fill = new SolidColorBrush(Color.FromArgb(60, 0, 255, 0)),
                    Smooth = false,             // TRUE for expensive curves
                    UseGradientFill = false,
                    MaxSamples = 40,
                    ShowGrid = false,
                    Background = Brushes.Black
                };

                ChartsPanel.Children.Add(chart);

                StartFeed(chart);
            }
        }

        private void StartFeed(AdvancedRealtimeChart chart)
        {
            Task.Run(() =>
            {
                Random r = new Random();
                double price = r.Next(80, 120);

                while (true)
                {
                    price += (r.NextDouble() - 0.5) * 2; // random walk

                    Dispatcher.Invoke(() =>
                    {
                        chart.Add(price);
                    });

                    Thread.Sleep(100); // 10 updates/sec per chart
                }
            });
        }
    }
}
