﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // START DUMMY LIVE UPDATE LOOP
            Task.Run(() =>
            {
                Random r = new Random();
                double price = 200;

                for (int i = 0; i < 5000; i++)
                {
                    price += (r.NextDouble() - 0.5) * 2;

                    Dispatcher.Invoke(() =>
                    {
                        chart.Add(price);   // <-- UPDATE CHART
                    });

                    Thread.Sleep(250);
                }
            });
        }
    }
}