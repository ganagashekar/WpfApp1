using System.Collections.Concurrent;

namespace FootprintDual.Models
{
    // ── Price level ───────────────────────────────────────────────────────────
    public sealed class FootprintLevel
    {
        public double Price    { get; }
        private long _bidVol, _askVol;
        public  long BidVol   => _bidVol;
        public  long AskVol   => _askVol;
        public  long TotalVol => _bidVol + _askVol;
        public  long Delta    => _askVol - _bidVol;
        public  double Imbalance => TotalVol > 0 ? (double)(_askVol - _bidVol) / TotalVol : 0;

        public FootprintLevel(double price) => Price = price;

        public void Add(long bidVol, long askVol)
        {
            Interlocked.Add(ref _bidVol, bidVol);
            Interlocked.Add(ref _askVol, askVol);
        }
    }

    // ── One 1-min candle ──────────────────────────────────────────────────────
    public sealed class FootprintCandle
    {
        public DateTime MinuteKey  { get; }       // floor to minute
        public OptionSide Side     { get; }       // CE or PE
        public bool  IsComplete    { get; private set; }

        // OHLC of the option premium
        private double _open, _high, _low, _close;
        private bool   _hasOpen;
        public double Open  => _open;
        public double High  => _high;
        public double Low   => _low;
        public double Close => _close;

        // Volume / delta totals
        private long _totalVol, _totalDelta;
        public long TotalVol   => _totalVol;
        public long TotalDelta => _totalDelta;

        // OI (snapshot from last tick)
        public long OI { get; private set; }

        // Price levels keyed by rounded price
        private readonly ConcurrentDictionary<long, FootprintLevel> _levels = new();
        private readonly double _bucket;

        public FootprintCandle(DateTime minuteKey, OptionSide side, double bucket)
        {
            MinuteKey = minuteKey; Side = side; _bucket = bucket;
        }

        public void OnTick(double price, long bidVol, long askVol, long totalVol, long oi)
        {
            lock (this)
            {
                if (!_hasOpen) { _open = price; _high = price; _low = price; _hasOpen = true; }
                if (price > _high) _high = price;
                if (price < _low)  _low  = price;
                _close = price;
                OI     = oi;
            }
            long key   = (long)Math.Round(price / _bucket);
            var  level = _levels.GetOrAdd(key, k => new FootprintLevel(k * _bucket));
            level.Add(bidVol, askVol);
            Interlocked.Add(ref _totalVol,   totalVol);
            Interlocked.Add(ref _totalDelta, askVol - bidVol);
        }

        public void MarkComplete() => IsComplete = true;

        public IReadOnlyList<FootprintLevel> GetLevels()
            => _levels.Values.OrderByDescending(l => l.Price).ToList();

        public FootprintLevel? POC()
        {
            var lvs = _levels.Values;
            return lvs.Count > 0 ? lvs.MaxBy(l => l.TotalVol) : null;
        }
    }

    // ── Cross-signal (one per minute, from CE+PE) ─────────────────────────────
    public sealed class CrossSignalBar
    {
        public string      TimeLabel  { get; set; } = "";
        public long        CeDelta    { get; set; }
        public long        PeDelta    { get; set; }
        public long        NetDelta   => CeDelta - PeDelta;  // CE_delta − PE_delta
        public double      PCR        { get; set; }          // PE_vol / CE_vol
        public CrossSignal Signal     { get; set; }
        public long        CeVol      { get; set; }
        public long        PeVol      { get; set; }
        public double      CeLast     { get; set; }
        public double      PeLast     { get; set; }
        public long        CeOI       { get; set; }
        public long        PeOI       { get; set; }

        public string SignalLabel => Signal switch
        {
            CrossSignal.StrongBull => "STRONG BULL",
            CrossSignal.StrongBear => "STRONG BEAR",
            CrossSignal.HedgedBull => "HEDGED BULL",
            CrossSignal.HedgedBear => "HEDGED BEAR",
            _                      => "NEUTRAL"
        };

        public bool IsBullish => Signal == CrossSignal.StrongBull || Signal == CrossSignal.HedgedBull;

        public static CrossSignal Classify(long ceD, long peD)
        {
            bool ceUp = ceD > 0, peUp = peD > 0;
            return (ceUp, peUp) switch
            {
                (true,  false) => CrossSignal.StrongBull,   // call buyers + put sellers
                (false, true)  => CrossSignal.StrongBear,   // call sellers + put buyers
                (true,  true)  => CrossSignal.HedgedBull,   // both buying = hedge/vol play
                (false, false) => CrossSignal.HedgedBear,   // both selling
                _              => CrossSignal.None
            };
        }
    }
}
