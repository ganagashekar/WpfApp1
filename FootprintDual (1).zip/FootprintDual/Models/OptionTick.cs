using MessagePack;

namespace FootprintDual.Models
{
    // ── Enums ─────────────────────────────────────────────────────────────────
    public enum OptionSide   { CE, PE }
    public enum TradeSide    { Unknown, BuyerInitiated, SellerInitiated }
    public enum CrossSignal  { None, StrongBull, StrongBear, HedgedBull, HedgedBear }

    // ── Raw MessagePack tick from ZeroMQ ─────────────────────────────────────
    // Key indices MUST match your existing feed server's serialisation order.
    // If your feed uses named keys, change [Key(N)] to [Key("fieldName")].
    [MessagePackObject]
    public sealed class OptionTick
    {
        [Key(0)]  public string Symbol      { get; set; } = "";
        [Key(1)]  public string Exchange    { get; set; } = "";
        [Key(2)]  public string RecvTs      { get; set; } = "";
        [Key(3)]  public double Open        { get; set; }
        [Key(4)]  public double Last        { get; set; }   // LTP
        [Key(5)]  public double High        { get; set; }
        [Key(6)]  public double Low         { get; set; }
        [Key(7)]  public double Change      { get; set; }
        [Key(8)]  public double BPrice      { get; set; }   // Best bid price
        [Key(9)]  public long   BQty        { get; set; }   // Best bid qty
        [Key(10)] public double SPrice      { get; set; }   // Best ask price
        [Key(11)] public long   SQty        { get; set; }   // Best ask qty
        [Key(12)] public long   Ltq         { get; set; }   // Last trade qty
        [Key(13)] public double AvgPrice    { get; set; }
        [Key(14)] public long   OI          { get; set; }   // Open Interest
        [Key(15)] public long   ChngOI      { get; set; }   // OI change
        [Key(16)] public long   Ttq         { get; set; }   // Cumulative traded qty
        [Key(17)] public long   TotalBuyQt  { get; set; }   // Cumulative buy qty
        [Key(18)] public long   TotalSellQ  { get; set; }   // Cumulative sell qty
        [Key(19)] public double Ttv         { get; set; }   // Traded value
        [Key(20)] public string Ltt         { get; set; } = ""; // Last trade time "Fri Apr 17 10:16:17 2026"
        [Key(21)] public double Close       { get; set; }

        // Parsed at ingest time — not serialised
        [IgnoreMember] public DateTime LttParsed  { get; set; }
        [IgnoreMember] public OptionSide Side      { get; set; }
        [IgnoreMember] public TradeSide  TradeDir  { get; set; }
        [IgnoreMember] public long       TickVol   { get; set; } // volume THIS tick
        [IgnoreMember] public long       BidVol    { get; set; }
        [IgnoreMember] public long       AskVol    { get; set; }

        // Alternate constructor for JSON log replay
        public static OptionTick FromJson(System.Text.Json.JsonElement el, OptionSide side)
        {
            var t = new OptionTick
            {
                Symbol    = el.TryGetProperty("symbol",      out var s)  ? s.GetString()  ?? "" : "",
                Last      = el.TryGetProperty("last",        out var l)  ? l.GetDouble()       : 0,
                High      = el.TryGetProperty("high",        out var h)  ? h.GetDouble()       : 0,
                Low       = el.TryGetProperty("low",         out var lo) ? lo.GetDouble()      : 0,
                BPrice    = el.TryGetProperty("bPrice",      out var bp) ? bp.GetDouble()      : 0,
                BQty      = el.TryGetProperty("bQty",        out var bq) ? bq.GetInt64()       : 0,
                SPrice    = el.TryGetProperty("sPrice",      out var sp) ? sp.GetDouble()      : 0,
                SQty      = el.TryGetProperty("sQty",        out var sq) ? sq.GetInt64()       : 0,
                Ltq       = el.TryGetProperty("ltq",         out var lq) ? lq.GetInt64()       : 0,
                OI        = el.TryGetProperty("OI",          out var oi) ? oi.GetInt64()       : 0,
                ChngOI    = el.TryGetProperty("CHNGOI",      out var co) ? co.GetInt64()       : 0,
                Ttq       = el.TryGetProperty("ttq",         out var tq) ? tq.GetInt64()       : 0,
                TotalBuyQt= el.TryGetProperty("totalBuyQt",  out var tb) ? tb.GetInt64()       : 0,
                TotalSellQ= el.TryGetProperty("totalSellQ",  out var ts) ? ts.GetInt64()       : 0,
                Close     = el.TryGetProperty("close",       out var c)  ? c.GetDouble()       : 0,
                Ltt       = el.TryGetProperty("ltt",         out var lt) ? lt.GetString() ?? "" : "",
                Side      = side,
            };
            return t;
        }
    }
}
