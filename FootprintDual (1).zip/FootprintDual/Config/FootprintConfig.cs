using System.Text.Json;
using System.Text.Json.Serialization;

namespace FootprintDual.Config
{
    public sealed class FootprintConfig
    {
        [JsonPropertyName("ZmqEndpoint")]
        public string ZmqEndpoint        { get; set; } = "tcp://localhost:5556";
        [JsonPropertyName("TopicPrefix")]
        public string TopicPrefix        { get; set; } = "NFO";
        [JsonPropertyName("Underlying")]
        public string Underlying         { get; set; } = "NIFTY BANK";
        [JsonPropertyName("Strike")]
        public int    Strike             { get; set; } = 56300;
        [JsonPropertyName("ExpiryDate")]
        public string ExpiryDate         { get; set; } = "2026-04-28";
        // Set these to your exact NSE symbols from the instrument master
        [JsonPropertyName("CeSymbol")]
        public string CeSymbol           { get; set; } = "BANKNIFTY2642856300CE";
        [JsonPropertyName("PeSymbol")]
        public string PeSymbol           { get; set; } = "BANKNIFTY2642856300PE";
        [JsonPropertyName("CandleMinutes")]
        public int    CandleMinutes      { get; set; } = 1;
        [JsonPropertyName("VisibleCandles")]
        public int    VisibleCandles     { get; set; } = 8;
        // Round premium prices to this bucket (0.5 recommended for BANKNIFTY)
        [JsonPropertyName("PriceBucket")]
        public double PriceBucket        { get; set; } = 0.5;
        // Imbalance threshold: 0.60 = cell colours at 3:2 bid/ask ratio
        [JsonPropertyName("ImbalanceThreshold")]
        public double ImbalanceThreshold { get; set; } = 0.60;
        // Leave empty for live ZMQ. Set to .log file path for offline replay
        [JsonPropertyName("LogReplayPath")]
        public string LogReplayPath      { get; set; } = "";
        // Max historical candles kept in memory
        [JsonPropertyName("MaxCandles")]
        public int    MaxCandles         { get; set; } = 100;

        public string ZmqTopicCE => $"{TopicPrefix}:{CeSymbol}";
        public string ZmqTopicPE => $"{TopicPrefix}:{PeSymbol}";

        public double Bucket(double p) => Math.Round(Math.Round(p / PriceBucket) * PriceBucket, 2);

        public static FootprintConfig Load(string path = "config.json")
        {
            if (!File.Exists(path))
            {
                var d = new FootprintConfig();
                File.WriteAllText(path, JsonSerializer.Serialize(d,
                    new JsonSerializerOptions { WriteIndented = true }));
                return d;
            }
            return JsonSerializer.Deserialize<FootprintConfig>(
                       File.ReadAllText(path)) ?? new FootprintConfig();
        }
    }
}
