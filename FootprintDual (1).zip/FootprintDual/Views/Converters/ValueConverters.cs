using System.Globalization;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;

namespace FootprintDual.Views.Converters
{
    // Usage: BackgroundColor="{Binding IsLive, Converter={StaticResource BoolColor},
    //                          ConverterParameter='#26A65B|#333'}"
    public sealed class BoolToColorConverter : IValueConverter
    {
        public object Convert(object? v, Type t, object? p, CultureInfo c)
        {
            bool b = v is true;
            var parts = ((string?)p ?? "#FFF|#333").Split('|');
            return Color.FromArgb(b ? parts[0] : parts[1]);
        }
        public object ConvertBack(object? v, Type t, object? p, CultureInfo c)
            => throw new NotSupportedException();
    }

    // Usage: Text="{Binding IsLive, Converter={StaticResource BoolText},
    //               ConverterParameter='● LIVE|○ OFFLINE'}"
    public sealed class BoolToTextConverter : IValueConverter
    {
        public object Convert(object? v, Type t, object? p, CultureInfo c)
        {
            bool b = v is true;
            var parts = ((string?)p ?? "|").Split('|');
            return b ? parts[0] : (parts.Length > 1 ? parts[1] : "");
        }
        public object ConvertBack(object? v, Type t, object? p, CultureInfo c)
            => throw new NotSupportedException();
    }
}
