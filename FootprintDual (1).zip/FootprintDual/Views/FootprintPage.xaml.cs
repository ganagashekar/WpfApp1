using FootprintDual.Models;
using FootprintDual.ViewModels;
using FootprintDual.Views.Drawables;
using Microsoft.Maui.Controls;

namespace FootprintDual.Views
{
    public partial class FootprintPage : ContentPage
    {
        private readonly FootprintViewModel    _vm;
        private readonly FootprintPanelDrawable _ceD = new() { Side = OptionSide.CE };
        private readonly FootprintPanelDrawable _peD = new() { Side = OptionSide.PE };
        private readonly VolumeProfileDrawable  _ceVP = new() { Side = OptionSide.CE };
        private readonly VolumeProfileDrawable  _peVP = new() { Side = OptionSide.PE };
        private int _selIdx = -1;

        public FootprintPage(FootprintViewModel vm)
        {
            InitializeComponent();
            _vm            = vm;
            BindingContext = _vm;

            // Wire drawables
            CeCanvas.Drawable   = _ceD;
            PeCanvas.Drawable   = _peD;
            CeVPCanvas.Drawable = _ceVP;
            PeVPCanvas.Drawable = _peVP;

            // Redraw on every tick update
            _vm.RedrawRequested += Redraw;

            // Dynamic info-bar colours
            _vm.PropertyChanged += (_, e) =>
            {
                if (e.PropertyName == nameof(_vm.NetDelta))
                    NetDeltaLabel.TextColor = _vm.NetDelta >= 0
                        ? Color.FromArgb("#26A65B") : Color.FromArgb("#E74C3C");
                if (e.PropertyName == nameof(_vm.CeDelta))
                    CeDeltaLabel.TextColor = _vm.CeDelta >= 0
                        ? Color.FromArgb("#26A65B") : Color.FromArgb("#E74C3C");
                if (e.PropertyName == nameof(_vm.PeDelta))
                    PeDeltaLabel.TextColor = _vm.PeDelta >= 0
                        ? Color.FromArgb("#26A65B") : Color.FromArgb("#E74C3C");
                if (e.PropertyName == nameof(_vm.Signal))
                    SignalLabel.TextColor = _vm.SignalBull
                        ? Color.FromArgb("#26A65B") : Color.FromArgb("#E74C3C");
            };

            // Tap CE/PE canvas → select candle + update info bar
            var ceGesture = new TapGestureRecognizer();
            ceGesture.Tapped += (_, e) => OnChartTapped(e, CeCanvas);
            CeCanvas.GestureRecognizers.Add(ceGesture);

            var peGesture = new TapGestureRecognizer();
            peGesture.Tapped += (_, e) => OnChartTapped(e, PeCanvas);
            PeCanvas.GestureRecognizers.Add(peGesture);

            // Tap signal bar cell
            SignalBar.SelectionMode = SelectionMode.Single;
            SignalBar.SelectionChanged += (_, e) =>
            {
                if (e.CurrentSelection.FirstOrDefault() is SignalVM sig)
                {
                    int idx = _vm.CrossSignals.IndexOf(sig);
                    _selIdx = idx;
                    _vm.UpdateInfoBarFromIndex(idx);
                    _ceD.SelectedIndex = idx;
                    _peD.SelectedIndex = idx;
                    Redraw();
                }
            };
        }

        private void OnChartTapped(TappedEventArgs e, GraphicsView canvas)
        {
            var pos = e.GetPosition(canvas);
            if (pos == null) return;
            float cW = Math.Min(140f, Math.Max(88f,
                (float)(canvas.Width - 48) / Math.Max(_vm.CeCandles.Count, 1) - 3f));
            int idx = (int)((pos.Value.X - 2) / (cW + 3f));
            int max = Math.Max(_vm.CeCandles.Count, _vm.PeCandles.Count);
            if (idx < 0 || idx >= max) return;
            _selIdx = idx;
            _vm.UpdateInfoBarFromIndex(idx);
            _ceD.SelectedIndex = idx;
            _peD.SelectedIndex = idx;
            Redraw();
        }

        private void Redraw()
        {
            var ceList = _vm.CeCandles.ToList();
            var peList = _vm.PeCandles.ToList();

            _ceD.Candles  = ceList;
            _peD.Candles  = peList;
            _ceD.ShowImbalance  = _vm.ShowImbalance;
            _peD.ShowImbalance  = _vm.ShowImbalance;
            _ceD.ShowDelta      = _vm.ShowDelta;
            _peD.ShowDelta      = _vm.ShowDelta;

            _ceVP.Candles = ceList;
            _peVP.Candles = peList;

            MainThread.BeginInvokeOnMainThread(() =>
            {
                CeCanvas.Invalidate();
                PeCanvas.Invalidate();
                CeVPCanvas.Invalidate();
                PeVPCanvas.Invalidate();
            });
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            Redraw();
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            _vm.RedrawRequested -= Redraw;
        }
    }
}
