using FootprintDual.Models;
using FootprintDual.ViewModels;
using Microsoft.Maui.Graphics;

namespace FootprintDual.Views.Drawables
{
    public sealed class VolumeProfileDrawable : IDrawable
    {
        public IList<CandleVM> Candles { get; set; } = Array.Empty<CandleVM>();
        public OptionSide Side         { get; set; } = OptionSide.CE;

        private static readonly Color BG     = Color.FromArgb("#0B0D12");
        private static readonly Color BAR_CE = Color.FromArgb("#1A2A40");
        private static readonly Color BAR_PE = Color.FromArgb("#2A1A10");
        private static readonly Color TEXT   = Color.FromArgb("#3A4050");
        private static readonly Color POC    = Color.FromArgb("#F5A623");

        public void Draw(ICanvas cv, RectF rect)
        {
            cv.FillColor = BG;
            cv.FillRectangle(rect);
            if (Candles.Count == 0) return;

            float W = rect.Width, H = rect.Height;
            const float ROW_H = 16f, FOOT_H = 44f, TIME_H = 17f;
            float chartH = H - FOOT_H - TIME_H;

            // Aggregate volume across all candles
            var vp = new Dictionary<double, long>();
            foreach (var c in Candles)
                foreach (var l in c.Levels)
                {
                    if (!vp.ContainsKey(l.Price)) vp[l.Price] = 0;
                    vp[l.Price] += l.TotalVol;
                }
            if (vp.Count == 0) return;

            long   maxVol = vp.Values.Max();
            double pMin   = vp.Keys.Min() - 0.5;
            double pMax   = vp.Keys.Max() + 0.5;
            double range  = pMax - pMin;
            if (range <= 0) return;

            double pocPrice = vp.MaxBy(kv => kv.Value).Key;

            Color barColor = Side == OptionSide.CE ? BAR_CE : BAR_PE;

            foreach (var (price, vol) in vp)
            {
                float y  = chartH - (float)((price - pMin) / range * chartH) - ROW_H / 2f;
                float bW = (float)((double)vol / maxVol * (W - 36f));

                cv.FillColor = Math.Abs(price - pocPrice) < 0.001 
                    ? Color.FromArgba(0.96f, 0.65f, 0.14f, 0.25f) : barColor;
                cv.FillRectangle(2, y, bW, ROW_H - 1);

                cv.FontSize  = 8f;
                cv.FontColor = Math.Abs(price - pocPrice) < 0.001 ? POC : TEXT;
                cv.DrawString(vol.ToString("N0"), bW + 4, y, W - bW - 6, ROW_H - 1,
                    HorizontalAlignment.Left, VerticalAlignment.Center);
            }

            // Label
            float lY = chartH + TIME_H + 4;
            cv.FontSize = 9f; cv.FontColor = barColor;
            cv.DrawString(Side == OptionSide.CE ? "CE Vol" : "PE Vol",
                0, lY, W, 14, HorizontalAlignment.Center, VerticalAlignment.Top);
        }
    }
}
