using FootprintDual.Models;
using FootprintDual.ViewModels;
using Microsoft.Maui.Graphics;

namespace FootprintDual.Views.Drawables
{
    public sealed class FootprintPanelDrawable : IDrawable
    {
        public IList<CandleVM> Candles    { get; set; } = Array.Empty<CandleVM>();
        public bool ShowImbalance         { get; set; } = true;
        public bool ShowDelta             { get; set; } = true;
        public OptionSide Side            { get; set; } = OptionSide.CE;
        public int SelectedIndex          { get; set; } = -1;

        private const float ROW_H   = 16f;
        private const float FOOT_H  = 44f;
        private const float TIME_H  = 17f;
        private const float AXIS_W  = 46f;

        // ── Colours ───────────────────────────────────────────────────────
        private static readonly Color BG        = Color.FromArgb("#0B0D12");
        private static readonly Color CELL      = Color.FromArgb("#111418");
        private static readonly Color CE_BULL   = Color.FromArgb("#0A1F35");
        private static readonly Color CE_BEAR   = Color.FromArgb("#1F1A0A");
        private static readonly Color CE_PBULL  = Color.FromArgb("#0D1820");
        private static readonly Color CE_PBEAR  = Color.FromArgb("#1A170A");
        private static readonly Color PE_BULL   = Color.FromArgb("#081A10");
        private static readonly Color PE_BEAR   = Color.FromArgb("#1A0808");
        private static readonly Color PE_PBULL  = Color.FromArgb("#0A1810");
        private static readonly Color PE_PBEAR  = Color.FromArgb("#180A0A");
        private static readonly Color POC_CE    = Color.FromArgb("#4A90E2");
        private static readonly Color POC_PE    = Color.FromArgb("#E59040");
        private static readonly Color POC_BG_CE = Color.FromArgba(0.18f, 0.35f, 0.55f, 0.18f);
        private static readonly Color POC_BG_PE = Color.FromArgba(0.55f, 0.35f, 0.10f, 0.18f);
        private static readonly Color TEXT      = Color.FromArgb("#C8D0DC");
        private static readonly Color MUTED     = Color.FromArgb("#3A4050");
        private static readonly Color BULL_WK   = Color.FromArgb("#26A65B");
        private static readonly Color BEAR_WK   = Color.FromArgb("#E74C3C");
        private static readonly Color D_GRN     = Color.FromArgb("#26A65B");
        private static readonly Color D_RED     = Color.FromArgb("#E74C3C");
        private static readonly Color GRID      = Color.FromArgb("#141820");
        private static readonly Color FOOTER    = Color.FromArgb("#090B10");
        private static readonly Color ACT_BDR_CE= Color.FromArgba(0.29f, 0.56f, 0.88f, 0.6f);
        private static readonly Color ACT_BDR_PE= Color.FromArgba(0.88f, 0.56f, 0.16f, 0.6f);
        private static readonly Color SEL_BDR   = Color.FromArgb("#2A3A50");

        public void Draw(ICanvas cv, RectF rect)
        {
            cv.FillColor = BG;
            cv.FillRectangle(rect);
            if (Candles.Count == 0) return;

            float W = rect.Width, H = rect.Height;
            float chartH = H - FOOT_H - TIME_H;
            float cW     = Math.Min(140f, Math.Max(88f,
                               (W - AXIS_W - 4f) / Candles.Count - 3f));

            // Price range
            double pMin = double.MaxValue, pMax = double.MinValue;
            foreach (var c in Candles)
                foreach (var l in c.Levels)
                {
                    if (l.TotalVol == 0) continue;
                    if (l.Price < pMin) pMin = l.Price;
                    if (l.Price > pMax) pMax = l.Price;
                }
            if (pMin > pMax) return;
            pMin -= 0.5; pMax += 0.5;
            double range = pMax - pMin;

            float PtoY(double p) =>
                chartH - (float)((p - pMin) / range * chartH);

            // Candles
            for (int ci = 0; ci < Candles.Count; ci++)
            {
                float x = ci * (cW + 3f) + 2f;
                DrawCandle(cv, Candles[ci], x, cW, chartH,
                    PtoY, ci == Candles.Count - 1,
                    ci == SelectedIndex || SelectedIndex < 0 && ci == Candles.Count - 1);
            }

            // Price axis
            DrawAxis(cv, W, chartH, pMin, pMax, PtoY);
        }

        private void DrawCandle(ICanvas cv, CandleVM c, float x, float cW,
            float chartH, Func<double, float> pty,
            bool isActive, bool isSelected)
        {
            // Column background
            cv.FillColor = isSelected ? Color.FromArgb("#111620") : BG;
            cv.FillRectangle(x, 0, cW, chartH);

            // Active / selected borders
            if (isActive && !c.IsComplete)
            {
                cv.StrokeColor = Side == OptionSide.CE ? ACT_BDR_CE : ACT_BDR_PE;
                cv.StrokeSize  = 1f;
                cv.DrawRectangle(x, 0, cW, chartH);
            }
            else if (isSelected)
            {
                cv.StrokeColor = SEL_BDR; cv.StrokeSize = 0.5f;
                cv.DrawRectangle(x, 0, cW, chartH);
            }

            // Price levels
            foreach (var lv in c.Levels)
            {
                if (lv.TotalVol == 0) continue;
                float y = pty(lv.Price) - ROW_H / 2f;

                Color bg = CELL;
                if (ShowImbalance)
                {
                    if (Side == OptionSide.CE)
                        bg = lv.IsBuyHeavy  ? CE_BULL
                           : lv.IsSellHeavy ? CE_BEAR
                           : lv.Imbalance > 0.2  ? CE_PBEAR
                           : lv.Imbalance < -0.2 ? CE_PBULL : CELL;
                    else
                        bg = lv.IsBuyHeavy  ? PE_BULL
                           : lv.IsSellHeavy ? PE_BEAR
                           : lv.Imbalance < -0.2 ? PE_PBULL
                           : lv.Imbalance > 0.2  ? PE_PBEAR : CELL;
                }
                if (lv.IsPOC)
                    bg = Side == OptionSide.CE ? POC_BG_CE : POC_BG_PE;

                cv.FillColor = bg;
                cv.FillRectangle(x + 1, y, cW - 2, ROW_H - 1);

                if (lv.IsPOC)
                {
                    cv.StrokeColor = Side == OptionSide.CE ? POC_CE : POC_PE;
                    cv.StrokeSize  = 1.2f;
                    cv.DrawRectangle(x + 1, y, cW - 2, ROW_H - 1);
                }

                bool bold = lv.IsPOC || lv.TotalVol > 2000;
                cv.FontSize  = 9f;
                cv.FontColor = lv.IsPOC
                    ? (Side == OptionSide.CE ? POC_CE : POC_PE)
                    : TEXT;
                cv.DrawString(lv.CellText, x, y, cW, ROW_H,
                    HorizontalAlignment.Center, VerticalAlignment.Center);
            }

            // Candle wick
            if (c.High > 0 && c.Low > 0)
            {
                float hiY = pty(c.High), loY = pty(c.Low) + ROW_H / 2f;
                cv.StrokeColor = c.IsBullish ? BULL_WK : BEAR_WK;
                cv.StrokeSize  = 1.5f;
                cv.DrawLine(x + cW / 2f, hiY, x + cW / 2f, loY);

                // Thin body
                float oY = pty(c.Open), cY = pty(c.Close);
                float bT = Math.Min(oY, cY), bH = Math.Max(Math.Abs(oY - cY), 2f);
                cv.FillColor = c.IsBullish
                    ? Color.FromArgba(0.15f, 0.65f, 0.36f, 0.45f)
                    : Color.FromArgba(0.88f, 0.30f, 0.24f, 0.45f);
                cv.FillRectangle(x + cW / 2f - 3f, bT, 6f, bH);
            }

            // Time label
            cv.FontSize  = 9f; cv.FontColor = MUTED;
            cv.DrawString(c.TimeLabel, x, chartH, cW, TIME_H,
                HorizontalAlignment.Center, VerticalAlignment.Center);

            // Footer
            float fY = chartH + TIME_H;
            cv.FillColor = FOOTER;
            cv.FillRectangle(x, fY, cW, FOOT_H);
            cv.StrokeColor = GRID; cv.StrokeSize = 0.5f;
            cv.DrawRectangle(x, fY, cW, FOOT_H);

            cv.FontSize = 10f; cv.FontColor = TEXT;
            cv.DrawString(c.TotalVol.ToString("N0"), x, fY + 2, cW, 16,
                HorizontalAlignment.Center, VerticalAlignment.Center);

            if (ShowDelta)
            {
                string dStr = $"{(c.Delta >= 0 ? "+" : "")}{c.Delta:N0}";
                cv.FontSize  = 9f;
                cv.FontColor = c.IsBullish ? D_GRN : D_RED;
                cv.DrawString(dStr, x, fY + 18, cW, 14,
                    HorizontalAlignment.Center, VerticalAlignment.Center);
            }

            // OI
            cv.FontSize  = 8f; cv.FontColor = MUTED;
            cv.DrawString($"OI {c.OI / 1000:N0}k", x, fY + 32, cW, 12,
                HorizontalAlignment.Center, VerticalAlignment.Center);
        }

        private void DrawAxis(ICanvas cv, float W, float chartH,
            double pMin, double pMax, Func<double, float> pty)
        {
            float axX = Candles.Count * 143f + 4f;
            double step = 2.0;
            double p    = Math.Ceiling(pMin / step) * step;

            cv.FontSize  = 8f; cv.FontColor = MUTED;
            while (p <= pMax)
            {
                float y = pty(p);
                cv.DrawString(p.ToString("F0"), axX, y - 6, AXIS_W - 2, 12,
                    HorizontalAlignment.Left, VerticalAlignment.Top);
                cv.StrokeColor = GRID; cv.StrokeSize = 0.3f;
                cv.DrawLine(2, y, axX - 2, y);
                p += step;
            }
        }
    }
}
