using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using FootprintDual.Config;
using FootprintDual.Models;
using FootprintDual.Services;
using Microsoft.Maui.Controls;

namespace FootprintDual.ViewModels
{
    public sealed class FootprintViewModel : INotifyPropertyChanged, IDisposable
    {
        private readonly FootprintConfig    _cfg;
        private readonly FootprintAggregator _agg;
        private readonly ZmqTickFeed        _feed;
        private readonly System.Timers.Timer _clockTimer;

        // ── Collections bound to the view ─────────────────────────────────
        public ObservableCollection<CandleVM>  CeCandles     { get; } = new();
        public ObservableCollection<CandleVM>  PeCandles     { get; } = new();
        public ObservableCollection<SignalVM>  CrossSignals  { get; } = new();

        // ── Scalar state ──────────────────────────────────────────────────
        private string _status = "Initialising…";
        private string _clock  = "--:--:--";
        private bool   _isLive;
        private bool   _showImbalance = true;
        private bool   _showDelta     = true;
        private bool   _showVolProfile= true;

        // Info bar — selected candle
        private string _selTime   = "--:--";
        private double _ceLast, _peLast;
        private long   _ceDelta,  _peDelta, _netDelta;
        private long   _ceVol,    _peVol;
        private long   _ceOI,     _peOI;
        private double _pcr;
        private string _signal    = "";
        private bool   _signalBull;

        public string Status    { get => _status;   set => Set(ref _status,   value); }
        public string Clock     { get => _clock;    set => Set(ref _clock,    value); }
        public bool   IsLive    { get => _isLive;   set => Set(ref _isLive,   value); }
        public bool   ShowImbalance  { get => _showImbalance;  set { Set(ref _showImbalance,  value); NotifyRedraw(); } }
        public bool   ShowDelta      { get => _showDelta;      set { Set(ref _showDelta,      value); NotifyRedraw(); } }
        public bool   ShowVolProfile { get => _showVolProfile; set { Set(ref _showVolProfile, value); NotifyRedraw(); } }

        public string SelTime   { get => _selTime;  set => Set(ref _selTime,  value); }
        public double CeLast    { get => _ceLast;   set => Set(ref _ceLast,   value); }
        public double PeLast    { get => _peLast;   set => Set(ref _peLast,   value); }
        public long   CeDelta   { get => _ceDelta;  set => Set(ref _ceDelta,  value); }
        public long   PeDelta   { get => _peDelta;  set => Set(ref _peDelta,  value); }
        public long   NetDelta  { get => _netDelta; set => Set(ref _netDelta, value); }
        public long   CeVol     { get => _ceVol;    set => Set(ref _ceVol,    value); }
        public long   PeVol     { get => _peVol;    set => Set(ref _peVol,    value); }
        public long   CeOI      { get => _ceOI;     set => Set(ref _ceOI,     value); }
        public long   PeOI      { get => _peOI;     set => Set(ref _peOI,     value); }
        public double PCR       { get => _pcr;      set => Set(ref _pcr,      value); }
        public string Signal    { get => _signal;   set => Set(ref _signal,   value); }
        public bool   SignalBull{ get => _signalBull;set => Set(ref _signalBull,value); }

        public string Underlying => _cfg.Underlying;
        public int    Strike     => _cfg.Strike;
        public string ExpiryDate => _cfg.ExpiryDate;
        public string CeSymbol   => _cfg.CeSymbol;
        public string PeSymbol   => _cfg.PeSymbol;

        // Fired when chart canvases must invalidate
        public event Action? RedrawRequested;

        // ── Commands ──────────────────────────────────────────────────────
        public ICommand ConnectCommand  { get; }
        public ICommand ReplayCommand   { get; }
        public ICommand ResetCommand    { get; }

        // ── Constructor ───────────────────────────────────────────────────
        public FootprintViewModel(FootprintConfig cfg, FootprintAggregator agg, ZmqTickFeed feed)
        {
            _cfg  = cfg;
            _agg  = agg;
            _feed = feed;

            // Wire aggregator events
            _agg.CandleUpdated   += OnCandleUpdated;
            _agg.CandleCompleted += OnCandleCompleted;
            _agg.SignalUpdated   += OnSignalUpdated;

            // Feed status
            _feed.StatusChanged += s => MainThread.BeginInvokeOnMainThread(
                () => { Status = s; IsLive = s.StartsWith("Connected"); });

            // Commands
            ConnectCommand = new Command(StartLive);
            ReplayCommand  = new Command(StartReplay);
            ResetCommand   = new Command(DoReset);

            // Clock
            _clockTimer = new System.Timers.Timer(1000);
            _clockTimer.Elapsed += (_, _) =>
                MainThread.BeginInvokeOnMainThread(
                    () => Clock = DateTime.Now.ToString("HH:mm:ss"));
            _clockTimer.Start();

            // Auto-start
            if (!string.IsNullOrWhiteSpace(cfg.LogReplayPath) &&
                File.Exists(cfg.LogReplayPath))
                StartReplay();
            else
                StartLive();
        }

        // ── Feed controls ─────────────────────────────────────────────────
        private void StartLive()
        {
            _feed.Start();
        }

        private async void StartReplay()
        {
            try
            {
                _agg.Reset();
                await _feed.ReplayLogAsync(_cfg.LogReplayPath);
            }
            catch (Exception ex)
            {
                Status = $"Replay error: {ex.Message}";
            }
        }

        private void DoReset()
        {
            _agg.Reset();
            MainThread.BeginInvokeOnMainThread(() =>
            {
                CeCandles.Clear();
                PeCandles.Clear();
                CrossSignals.Clear();
                RedrawRequested?.Invoke();
            });
        }

        // ── Aggregator callbacks ──────────────────────────────────────────
        private void OnCandleUpdated(FootprintCandle c)
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                RefreshCandleList(c.Side);
                RedrawRequested?.Invoke();
            });
        }

        private void OnCandleCompleted(FootprintCandle c)
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                RefreshCandleList(c.Side);
                RedrawRequested?.Invoke();
            });
        }

        private void OnSignalUpdated(CrossSignalBar sig)
        {
            MainThread.BeginInvokeOnMainThread(() => RefreshSignalList(sig));
        }

        // ── Rebuild observable collections ────────────────────────────────
        private void RefreshCandleList(OptionSide side)
        {
            var raw  = side == OptionSide.CE
                ? _agg.GetCE(_cfg.VisibleCandles)
                : _agg.GetPE(_cfg.VisibleCandles);
            var coll = side == OptionSide.CE ? CeCandles : PeCandles;

            coll.Clear();
            foreach (var c in raw)
                coll.Add(new CandleVM(c, _cfg));
        }

        private void RefreshSignalList(CrossSignalBar sig)
        {
            var all = _agg.GetCrossSignals();
            CrossSignals.Clear();
            foreach (var s in all)
                CrossSignals.Add(new SignalVM(s));

            // Update info bar from latest signal
            UpdateInfoBar(sig);
        }

        // ── Info bar update ───────────────────────────────────────────────
        public void UpdateInfoBar(CrossSignalBar sig)
        {
            SelTime   = sig.TimeLabel;
            CeLast    = sig.CeLast;
            PeLast    = sig.PeLast;
            CeDelta   = sig.CeDelta;
            PeDelta   = sig.PeDelta;
            NetDelta  = sig.NetDelta;
            CeVol     = sig.CeVol;
            PeVol     = sig.PeVol;
            CeOI      = sig.CeOI;
            PeOI      = sig.PeOI;
            PCR       = sig.PCR;
            Signal    = sig.SignalLabel;
            SignalBull= sig.IsBullish;
        }

        public void UpdateInfoBarFromIndex(int idx)
        {
            var sigs = _agg.GetCrossSignals();
            if (idx >= 0 && idx < sigs.Count)
                UpdateInfoBar(sigs[idx]);
        }

        private void NotifyRedraw() => RedrawRequested?.Invoke();

        // ── INotifyPropertyChanged ────────────────────────────────────────
        public event PropertyChangedEventHandler? PropertyChanged;
        private void Set<T>(ref T f, T v, [CallerMemberName] string? n = null)
        {
            if (EqualityComparer<T>.Default.Equals(f, v)) return;
            f = v;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
        }

        public void Dispose()
        {
            _clockTimer.Dispose();
            _agg.CandleUpdated   -= OnCandleUpdated;
            _agg.CandleCompleted -= OnCandleCompleted;
            _agg.SignalUpdated   -= OnSignalUpdated;
            _feed.Dispose();
        }
    }

    // ── Per-candle ViewModel ──────────────────────────────────────────────────
    public sealed class CandleVM
    {
        public string  TimeLabel  { get; }
        public double  Open       { get; }
        public double  High       { get; }
        public double  Low        { get; }
        public double  Close      { get; }
        public long    TotalVol   { get; }
        public long    Delta      { get; }
        public bool    IsComplete { get; }
        public bool    IsBullish  => Delta >= 0;
        public OptionSide Side    { get; }
        public long    OI         { get; }
        public double? POCPrice   { get; }
        public IReadOnlyList<LevelVM> Levels { get; }

        public CandleVM(FootprintCandle c, FootprintConfig cfg)
        {
            TimeLabel  = c.MinuteKey.ToLocalTime().ToString("HH:mm");
            Open       = c.Open;
            High       = c.High;
            Low        = c.Low;
            Close      = c.Close;
            TotalVol   = c.TotalVol;
            Delta      = c.TotalDelta;
            IsComplete = c.IsComplete;
            Side       = c.Side;
            OI         = c.OI;
            POCPrice   = c.POC()?.Price;

            Levels = c.GetLevels()
                       .Select(l => new LevelVM(l, c.Side, cfg.ImbalanceThreshold, POCPrice))
                       .ToList();
        }
    }

    // ── Per-level ViewModel ───────────────────────────────────────────────────
    public sealed class LevelVM
    {
        public double  Price       { get; }
        public long    BidVol      { get; }
        public long    AskVol      { get; }
        public long    TotalVol    { get; }
        public long    Delta       { get; }
        public double  Imbalance   { get; }
        public bool    IsPOC       { get; }
        public bool    IsBuyHeavy  { get; }
        public bool    IsSellHeavy { get; }
        public string  CellText    { get; }
        public OptionSide Side     { get; }

        public LevelVM(FootprintLevel l, OptionSide side,
                       double threshold, double? poc)
        {
            Price      = l.Price;
            BidVol     = l.BidVol;
            AskVol     = l.AskVol;
            TotalVol   = l.TotalVol;
            Delta      = l.Delta;
            Imbalance  = l.Imbalance;
            IsPOC      = poc.HasValue && Math.Abs(l.Price - poc.Value) < 0.001;
            Side       = side;
            CellText   = $"{BidVol}×{AskVol}";

            // Colour logic:
            // CE: ask-heavy = bullish (call buyers aggressive)
            // PE: ask-heavy = bearish (put buyers aggressive), bid-heavy = bullish
            if (side == OptionSide.CE)
            {
                IsBuyHeavy  = Imbalance >  threshold;  // ask > bid → CE buyers
                IsSellHeavy = Imbalance < -threshold;  // bid > ask → CE sellers
            }
            else
            {
                IsBuyHeavy  = Imbalance < -threshold;  // bid > ask → PE sellers = bullish
                IsSellHeavy = Imbalance >  threshold;  // ask > bid → PE buyers  = bearish
            }
        }
    }

    // ── Signal bar ViewModel ──────────────────────────────────────────────────
    public sealed class SignalVM
    {
        public CrossSignalBar Raw { get; }
        public string TimeLabel   => Raw.TimeLabel;
        public string SignalLabel => Raw.SignalLabel;
        public bool   IsBullish   => Raw.IsBullish;
        public long   NetDelta    => Raw.NetDelta;
        public double PCR         => Raw.PCR;
        public long   CeDelta     => Raw.CeDelta;
        public long   PeDelta     => Raw.PeDelta;
        public string NetDeltaFmt => $"{(NetDelta >= 0 ? "+" : "")}{NetDelta:N0}";
        public string CeDeltaFmt  => $"CE δ{(CeDelta >= 0 ? "+" : "")}{CeDelta:N0}";
        public string PeDeltaFmt  => $"PE δ{(PeDelta >= 0 ? "+" : "")}{PeDelta:N0}";

        public SignalVM(CrossSignalBar raw) => Raw = raw;
    }
}
