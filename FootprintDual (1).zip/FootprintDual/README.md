# NIFTY BANK CE+PE Dual Footprint Chart — Plug & Play Guide

## Quick start (3 steps)

### Step 1 — Edit config.json
```json
{
  "ZmqEndpoint": "tcp://YOUR_FEED_HOST:5556",
  "CeSymbol":    "BANKNIFTY2642856300CE",
  "PeSymbol":    "BANKNIFTY2642856300PE",
  "Strike":      56300,
  "ExpiryDate":  "2026-04-28",
  "LogReplayPath": ""
}
```
Set `LogReplayPath` to a `.log` file path for offline replay.
Leave it empty string for live ZeroMQ feed.

### Step 2 — Verify MessagePack key order
Open `Models/OptionTick.cs`. The `[Key(N)]` indices must match
your feed server's serialisation order exactly.
If your server uses named keys, change `[Key(0)]` → `[Key("symbol")]` etc.

### Step 3 — Build and run
```bash
dotnet build
dotnet run
```

---

## Project structure
```
FootprintDual/
├── config.json                      ← Edit this — no recompile needed
├── Config/FootprintConfig.cs        ← All config loaded from config.json
├── Models/
│   ├── OptionTick.cs                ← MessagePack tick + JSON replay
│   └── FootprintModels.cs           ← Level, Candle, CrossSignalBar
├── Services/
│   ├── FootprintAggregator.cs       ← Core: builds candles, cross-signal
│   └── ZmqTickFeed.cs               ← ZeroMQ SUB + log replay
├── ViewModels/
│   └── FootprintViewModel.cs        ← All VMs: Candle, Level, Signal
├── Views/
│   ├── FootprintPage.xaml           ← MAUI layout
│   ├── FootprintPage.xaml.cs        ← Canvas wiring, tap handlers
│   ├── Converters/ValueConverters.cs
│   └── Drawables/
│       ├── FootprintPanelDrawable.cs ← CE/PE canvas renderer
│       └── VolumeProfileDrawable.cs  ← Vol profile renderer
├── App.xaml / App.xaml.cs
├── AppShell.xaml / AppShell.xaml.cs
├── MauiProgram.cs
└── FootprintDual.csproj
```

---

## How trade-side classification works
```
LTP >= SPrice (best ask)  → BuyerInitiated   → AskVol += tickVol
LTP <= BPrice (best bid)  → SellerInitiated  → BidVol += tickVol
else (midpoint)           → Unknown          → BidVol = BQty, AskVol = SQty
```

## Colour logic
| Panel | Cell colour | Meaning |
|---|---|---|
| CE | Green (ask-heavy) | Call buyers aggressive → bullish |
| CE | Red (bid-heavy)   | Call sellers aggressive → bearish |
| PE | Green (bid-heavy) | Put sellers aggressive → bullish |
| PE | Red (ask-heavy)   | Put buyers aggressive → bearish |

## Cross-signal classification
| CE δ | PE δ | Signal | Meaning |
|---|---|---|---|
| + | − | STRONG BULL | Call buyers + put sellers |
| − | + | STRONG BEAR | Call sellers + put buyers |
| + | + | HEDGED BULL | Both buying — volatility/hedge |
| − | − | HEDGED BEAR | Both selling |

## NuGet packages
```xml
<PackageReference Include="NetMQ"       Version="4.0.1.13"/>
<PackageReference Include="MessagePack" Version="2.5.192"/>
```

## Log replay
Set `LogReplayPath` in config.json to your `.log` file.
The replay reads JSON lines, filters by `strike_price`, classifies
CE/PE from the `right` field, and feeds ticks into the aggregator
at ~60fps so the UI renders smoothly.
