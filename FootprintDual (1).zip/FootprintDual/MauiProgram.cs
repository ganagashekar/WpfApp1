using FootprintDual.Config;
using FootprintDual.Services;
using FootprintDual.ViewModels;
using FootprintDual.Views;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Maui.Controls.Hosting;
using Microsoft.Maui.Hosting;

namespace FootprintDual
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

            // ── Load config (creates config.json with defaults if missing) ──
            var cfg = FootprintConfig.Load(
                Path.Combine(AppContext.BaseDirectory, "config.json"));

            builder.Services.AddSingleton(cfg);
            builder.Services.AddSingleton<FootprintAggregator>();
            builder.Services.AddSingleton<ZmqTickFeed>();
            builder.Services.AddSingleton<FootprintViewModel>();
            builder.Services.AddTransient<FootprintPage>();

            return builder.Build();
        }
    }
}
