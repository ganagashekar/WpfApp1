using FootprintDual.Config;
using FootprintDual.Models;
using MessagePack;
using NetMQ;
using NetMQ.Sockets;

namespace FootprintDual.Services
{
    /// <summary>
    /// ZeroMQ SUB socket subscriber.
    /// Subscribes to both CE and PE topics, deserialises MessagePack ticks,
    /// parses LTT timestamps, and routes to FootprintAggregator.
    ///
    /// PLUG-AND-PLAY: set ZmqEndpoint, CeSymbol, PeSymbol in config.json.
    /// </summary>
    public sealed class ZmqTickFeed : IDisposable
    {
        private readonly FootprintConfig    _cfg;
        private readonly FootprintAggregator _agg;
        private readonly TickPreprocessor   _prep;

        private SubscriberSocket? _socket;
        private CancellationTokenSource? _cts;
        private Task? _loop;

        public event Action<string>? StatusChanged;

        public ZmqTickFeed(FootprintConfig cfg, FootprintAggregator agg)
        {
            _cfg  = cfg;
            _agg  = agg;
            _prep = new TickPreprocessor(cfg);
        }

        // ── Start live ZeroMQ feed ────────────────────────────────────────
        public void Start()
        {
            _cts    = new CancellationTokenSource();
            _socket = new SubscriberSocket();
            _socket.Connect(_cfg.ZmqEndpoint);
            _socket.Subscribe(_cfg.ZmqTopicCE);
            _socket.Subscribe(_cfg.ZmqTopicPE);

            StatusChanged?.Invoke($"Connected → {_cfg.ZmqEndpoint}");
            var ct = _cts.Token;
            _loop  = Task.Factory.StartNew(
                () => LiveLoop(ct),
                ct, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        private void LiveLoop(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    if (!_socket!.TryReceiveFrameString(
                            TimeSpan.FromMilliseconds(100), out var topic))
                        continue;
                    if (!_socket.TryReceiveFrameBytes(out var payload)) continue;

                    bool isCE = topic.EndsWith(_cfg.CeSymbol, StringComparison.Ordinal);
                    bool isPE = topic.EndsWith(_cfg.PeSymbol, StringComparison.Ordinal);
                    if (!isCE && !isPE) continue;

                    var tick = MessagePackSerializer.Deserialize<OptionTick>(payload);
                    tick.Side = isCE ? OptionSide.CE : OptionSide.PE;

                    if (_prep.Process(tick))
                        _agg.OnTick(tick);
                }
                catch (OperationCanceledException) { break; }
                catch (Exception ex)
                {
                    StatusChanged?.Invoke($"ZMQ error: {ex.Message}");
                    Thread.Sleep(500);
                }
            }
            StatusChanged?.Invoke("Disconnected");
        }

        // ── Log replay (offline testing) ──────────────────────────────────
        public async Task ReplayLogAsync(string path, CancellationToken ct = default)
        {
            StatusChanged?.Invoke($"Replaying: {Path.GetFileName(path)}");
            int count = 0;

            await foreach (var line in File.ReadLinesAsync(path, ct))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                try
                {
                    using var doc = System.Text.Json.JsonDocument.Parse(line);
                    var root = doc.RootElement;

                    // Determine CE or PE from the 'right' field
                    string? right = root.TryGetProperty("right", out var rv)
                        ? rv.GetString() : null;
                    var side = right == "Call" ? OptionSide.CE : OptionSide.PE;

                    // Only process our target strike
                    if (root.TryGetProperty("strike_price", out var sp))
                    {
                        int strike = (int)double.Parse(sp.GetString() ?? "0");
                        if (strike != _cfg.Strike) continue;
                    }

                    var tick = OptionTick.FromJson(root, side);
                    if (_prep.Process(tick))
                        _agg.OnTick(tick);
                    count++;

                    // Throttle replay so UI can render
                    if (count % 50 == 0)
                        await Task.Delay(16, ct); // ~60fps
                }
                catch { /* skip malformed lines */ }
            }
            StatusChanged?.Invoke($"Replay complete — {count} ticks processed");
        }

        public void Stop()
        {
            _cts?.Cancel();
            _loop?.Wait(2000);
            _socket?.Dispose();
            _cts?.Dispose();
        }

        public void Dispose() => Stop();
    }

    // ── Tick pre-processor: parse LTT, compute tick volume, classify side ──────
    internal sealed class TickPreprocessor
    {
        private readonly FootprintConfig _cfg;
        private readonly Dictionary<string, (long ttq, long buy, long sell)> _prev = new();

        public TickPreprocessor(FootprintConfig cfg) => _cfg = cfg;

        // Returns true if tick is valid and ready for aggregator
        public bool Process(OptionTick t)
        {
            if (t.Last <= 0) return false;

            // ── Parse LTT ─────────────────────────────────────────────────
            if (!TryParseLtt(t.Ltt, out var ltt)) return false;
            t.LttParsed = ltt;

            // ── Market hours filter ───────────────────────────────────────
            var tod = ltt.TimeOfDay;
            if (tod < new TimeSpan(9,15,0) || tod > new TimeSpan(15,30,0)) return false;

            // ── Tick volume from cumulative diff ──────────────────────────
            if (_prev.TryGetValue(t.Symbol, out var prev))
            {
                t.TickVol = Math.Max(0, t.Ttq - prev.ttq);
                if (t.TickVol == 0) t.TickVol = t.Ltq;
            }
            else { t.TickVol = t.Ltq; }
            _prev[t.Symbol] = (t.Ttq, t.TotalBuyQt, t.TotalSellQ);

            // ── Trade-side classification ─────────────────────────────────
            if      (t.SPrice > 0 && t.Last >= t.SPrice)
            { t.AskVol = t.TickVol; t.BidVol = 0; t.TradeDir = TradeSide.BuyerInitiated; }
            else if (t.BPrice > 0 && t.Last <= t.BPrice)
            { t.BidVol = t.TickVol; t.AskVol = 0; t.TradeDir = TradeSide.SellerInitiated; }
            else
            { t.BidVol = t.BQty; t.AskVol = t.SQty; t.TradeDir = TradeSide.Unknown; }

            return true;
        }

        private static bool TryParseLtt(string ltt, out DateTime result)
        {
            result = default;
            if (string.IsNullOrWhiteSpace(ltt)) return false;
            // "Fri Apr 17 10:16:17 2026" — feed format
            return DateTime.TryParseExact(ltt.Trim(),
                "ddd MMM d HH:mm:ss yyyy",
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out result)
            || DateTime.TryParse(ltt, out result);
        }
    }
}
