using FootprintDual.Config;
using FootprintDual.Models;
using System.Collections.Concurrent;

namespace FootprintDual.Services
{
    /// <summary>
    /// Receives CE and PE ticks, classifies trade side, builds FootprintCandle
    /// objects, and exposes CrossSignalBar for the middle panel.
    ///
    /// Thread-safe: ZMQ receiver threads call OnTick directly.
    /// </summary>
    public sealed class FootprintAggregator
    {
        private readonly FootprintConfig _cfg;

        // ── Active candles ────────────────────────────────────────────────────
        private readonly object _lock = new();
        private FootprintCandle? _activeCE, _activePE;

        // ── History (completed candles, newest at end) ─────────────────────
        private readonly List<FootprintCandle> _histCE = new();
        private readonly List<FootprintCandle> _histPE = new();

        // ── Previous cumulative values for delta (per symbol) ─────────────
        private readonly ConcurrentDictionary<string, (long ttq, long buy, long sell)> _prev = new();

        // ── Cross signals ─────────────────────────────────────────────────
        private readonly List<CrossSignalBar> _crossSignals = new();

        // ── Events ────────────────────────────────────────────────────────
        public event Action<FootprintCandle>? CandleUpdated;
        public event Action<FootprintCandle>? CandleCompleted;
        public event Action<CrossSignalBar>?  SignalUpdated;

        public FootprintAggregator(FootprintConfig cfg) => _cfg = cfg;

        // ── Main entry ────────────────────────────────────────────────────
        public void OnTick(OptionTick t)
        {
            if (t.Last <= 0 || t.LttParsed == default) return;

            // ── Delta: diff vs previous cumulative ────────────────────────
            var prev = _prev.GetOrAdd(t.Symbol, _ => (t.Ttq, t.TotalBuyQt, t.TotalSellQ));
            long tickVol = Math.Max(0, t.Ttq - prev.ttq);
            if (tickVol == 0) tickVol = t.Ltq;
            _prev[t.Symbol] = (t.Ttq, t.TotalBuyQt, t.TotalSellQ);

            // ── Trade-side classification ─────────────────────────────────
            long bidVol, askVol;
            if (t.SPrice > 0 && t.Last >= t.SPrice)       // lifted ask → buyer
            { askVol = tickVol; bidVol = 0; }
            else if (t.BPrice > 0 && t.Last <= t.BPrice)  // hit bid → seller
            { bidVol = tickVol; askVol = 0; }
            else                                           // midpoint → quote proxy
            { bidVol = t.BQty; askVol = t.SQty; }

            t.TickVol = tickVol; t.BidVol = bidVol; t.AskVol = askVol;

            // ── Candle boundary ────────────────────────────────────────────
            DateTime minuteKey = FloorMinute(t.LttParsed);

            lock (_lock)
            {
                ref var active = ref (t.Side == OptionSide.CE ? ref _activeCE : ref _activePE);
                var hist       = t.Side == OptionSide.CE ? _histCE : _histPE;

                if (active == null || active.MinuteKey != minuteKey)
                {
                    if (active != null)
                    {
                        active.MarkComplete();
                        hist.Add(active);
                        if (hist.Count > _cfg.MaxCandles) hist.RemoveAt(0);
                        var done = active;
                        Task.Run(() => CandleCompleted?.Invoke(done));
                        RebuildCrossSignal(minuteKey);
                    }
                    active = new FootprintCandle(minuteKey, t.Side, _cfg.PriceBucket);
                }

                active.OnTick(t.Last, bidVol, askVol, tickVol, t.OI);
                var snap = active;
                Task.Run(() => CandleUpdated?.Invoke(snap));
                UpdateLiveCrossSignal();
            }
        }

        // ── Read-side ─────────────────────────────────────────────────────
        public IReadOnlyList<FootprintCandle> GetCE(int count)
        {
            lock (_lock)
            {
                var result = _histCE.TakeLast(count - 1).ToList();
                if (_activeCE != null) result.Add(_activeCE);
                return result;
            }
        }

        public IReadOnlyList<FootprintCandle> GetPE(int count)
        {
            lock (_lock)
            {
                var result = _histPE.TakeLast(count - 1).ToList();
                if (_activePE != null) result.Add(_activePE);
                return result;
            }
        }

        public IReadOnlyList<CrossSignalBar> GetCrossSignals()
        {
            lock (_lock) return _crossSignals.TakeLast(_cfg.VisibleCandles).ToList();
        }

        public (FootprintCandle? CE, FootprintCandle? PE) ActiveCandles
        {
            get { lock (_lock) return (_activeCE, _activePE); }
        }

        // ── Cross signal builder ──────────────────────────────────────────
        private void RebuildCrossSignal(DateTime minuteKey)
        {
            // Called when a candle completes — look at the completed candle pair
            var ce = _histCE.LastOrDefault();
            var pe = _histPE.LastOrDefault();
            if (ce == null && pe == null) return;

            BuildSignal(ce, pe);
        }

        private void UpdateLiveCrossSignal()
        {
            BuildSignal(_activeCE, _activePE);
        }

        private void BuildSignal(FootprintCandle? ce, FootprintCandle? pe)
        {
            if (ce == null && pe == null) return;
            var tKey = (ce ?? pe)!.MinuteKey;
            long ceD = ce?.TotalDelta ?? 0;
            long peD = pe?.TotalDelta ?? 0;
            long ceV = ce?.TotalVol   ?? 0;
            long peV = pe?.TotalVol   ?? 0;

            var sig = new CrossSignalBar
            {
                TimeLabel = tKey.ToString("HH:mm"),
                CeDelta   = ceD, PeDelta = peD,
                CeVol     = ceV, PeVol   = peV,
                PCR       = ceV > 0 ? Math.Round((double)peV / ceV, 3) : 0,
                Signal    = CrossSignal.Classify(ceD, peD),
                CeLast    = ce?.Close  ?? 0,
                PeLast    = pe?.Close  ?? 0,
                CeOI      = ce?.OI     ?? 0,
                PeOI      = pe?.OI     ?? 0,
            };

            // Update or append
            var existing = _crossSignals.FindIndex(x => x.TimeLabel == sig.TimeLabel);
            if (existing >= 0) _crossSignals[existing] = sig;
            else _crossSignals.Add(sig);
            if (_crossSignals.Count > _cfg.MaxCandles)
                _crossSignals.RemoveAt(0);

            Task.Run(() => SignalUpdated?.Invoke(sig));
        }

        // ── Session reset ─────────────────────────────────────────────────
        public void Reset()
        {
            lock (_lock)
            {
                _activeCE = _activePE = null;
                _histCE.Clear(); _histPE.Clear(); _crossSignals.Clear();
                _prev.Clear();
            }
        }

        private static DateTime FloorMinute(DateTime dt)
            => new(dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, 0, dt.Kind);
    }
}
